{{- define "modules.serviceMonitor" }}

{{- $defaultLabel := dict "release" (default "prometheus" .serviceMonitor.prometheusReleaseName) -}}
{{- $labels := $defaultLabel -}}
{{- if .serviceMonitor.AdditionalLabels}}
  {{- $labels = merge $labels .serviceMonitor.AdditionalLabels -}}
{{- end -}}

{{- $defaultMatchLabel := dict "app.kubernetes.io/name" .name -}}
{{- $matchLabels := $defaultMatchLabel -}}
{{- if .kube_service_config.labels}}
  {{- $matchLabels = merge $matchLabels .kube_service_config.labels -}}
{{- end -}}

{{- if .serviceMonitor.enabled}}
apiVersion: monitoring.coreos.com/v1
kind: ServiceMonitor
metadata:
  name: {{ .name}}-{{ .namespace }}-sm
  namespace: {{ .serviceMonitor.serviceMonitorNamespace | default "monitoring" }}
  labels:
    {{- toYaml $labels | nindent 4 }}
spec:
  selector:
    matchLabels: {{- toYaml $matchLabels | nindent 6 }}
  namespaceSelector:
    matchNames: 
      - {{ .serviceMonitor.namespace | default .namespace }}
  endpoints:
    - port: {{ .serviceMonitor.portName | default "http"}}
      interval: {{ .serviceMonitor.interval }}
      path: {{ .serviceMonitor.path }}
{{- end }}
{{- end }}

