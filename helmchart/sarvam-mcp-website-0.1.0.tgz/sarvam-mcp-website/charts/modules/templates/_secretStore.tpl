{{- define "modules.secretStore" -}}
{{- if .secretStoreDefinition.enabled }}
apiVersion: external-secrets.io/v1
kind: {{ .secretStoreDefinition.kind }}
metadata:
  name: {{ .secretStoreDefinition.name }}
  {{- if eq .secretStoreDefinition.kind "SecretStore" }}
  namespace: {{ .secretStoreDefinition.namespace }}
  {{- end }}
  labels:
    {{- range $key, $value := .commonLabels }}
    {{ $key }}: {{ tpl $value $ | quote }}
    {{- end }}
    {{- with .secretStoreDefinition.labels }}
    {{- toYaml . | nindent 4 }}
    {{- end }}
spec:
  provider:
    vault:
      server: {{ .secretStoreDefinition.provider.vault.server }}
      path: {{ .secretStoreDefinition.provider.vault.path }}
      version: {{ .secretStoreDefinition.provider.vault.version }}
      namespace: {{ .secretStoreDefinition.provider.vault.namespace }}
      caProvider:
        type: {{ .secretStoreDefinition.provider.vault.caProvider.type }}
        name: {{ .secretStoreDefinition.provider.vault.caProvider.name }}
        key: {{ .secretStoreDefinition.provider.vault.caProvider.key }}
      auth:
        kubernetes:
          mountPath: {{ .secretStoreDefinition.provider.vault.auth.kubernetes.mountPath }}
          role: {{ .secretStoreDefinition.provider.vault.auth.kubernetes.role }}
          serviceAccountRef:
            name: {{ .secretStoreDefinition.provider.vault.auth.kubernetes.serviceAccountRef.name }}
            namespace: {{ .secretStoreDefinition.provider.vault.auth.kubernetes.serviceAccountRef.namespace }}
{{- end }}
{{- end }}