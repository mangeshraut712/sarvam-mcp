{{- define "modules.service" -}}

{{- $defaultSelectors := dict "app.kubernetes.io/name" .name -}}

{{- $selectors := $defaultSelectors -}}
{{- if .kube_service_config.selectors }}
  {{- $selectors := merge $defaultSelectors .kube_service_config.selectors -}}
{{- end }}

{{- $serviceName := .name}}
{{- if .kube_service_config.name }}
  {{- $serviceName = .kube_service_config.name }}
{{- end }}

{{- $serviceNamespace := .namespace}}
{{- if .kube_service_config.namespace }}
  {{- $serviceNamespace = .kube_service_config.namespace }}
{{- end }}

{{- $defaultLabel := dict "app.kubernetes.io/name" .name -}}
{{- $labels := $defaultLabel -}}
{{- if .kube_service_config.labels}}
  {{- $labels = merge $labels .kube_service_config.labels -}}
{{- end -}}

apiVersion: v1
kind: Service
metadata:
  name: {{ $serviceName }}
  namespace: {{ $serviceNamespace }}
  labels:
    {{- toYaml $labels | nindent 4 }}
spec:
  selector: {{- toYaml $selectors | nindent 4 }}
  type: {{ .kube_service_config.type | default "ClusterIP" }}
  ports:
    {{- range $name, $port := .kube_service_config.ports }}
    - name: {{ $name }}
      protocol: {{ $port.protocol | default "TCP" }}
      port: {{ $port.port }}
      targetPort: {{ $port.targetPort }}
    {{- end }}
{{- end -}}