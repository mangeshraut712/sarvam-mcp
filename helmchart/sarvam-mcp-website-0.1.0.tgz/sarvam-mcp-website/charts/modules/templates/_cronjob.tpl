{{- define "modules.cronjob" -}}

{{- $cronJobName := .name -}}
{{- if .cronjob_name }}
  {{- $cronJobName = .cronjob_name -}}
{{- end }}

{{- $namespace := .namespace -}}

{{- $defaultLabels := dict "app.kubernetes.io/name" .name -}}
{{- $labels := $defaultLabels -}}
{{- if .labels }}
  {{- $labels = merge $defaultLabels .labels -}}
{{- end }}

{{- $defaultPodLabels := dict 
    "app.kubernetes.io/name" .name
    "azure.workload.identity/use" "true"
-}}
{{- $podLabels := $defaultPodLabels -}}
{{- if .pod_labels }}
  {{- $podLabels = merge $defaultPodLabels .pod_labels -}}
{{- end }}

apiVersion: batch/v1
kind: CronJob
metadata:
  name: {{ $cronJobName }}
  namespace: {{ $namespace }}
  labels:
    {{- toYaml $labels | nindent 4 }}
spec:
  schedule: {{ .schedule | quote }}
  concurrencyPolicy: {{ .concurrencyPolicy | default "Forbid" }}
  successfulJobsHistoryLimit: {{ .successfulJobsHistoryLimit | default 3 }}
  failedJobsHistoryLimit: {{ .failedJobsHistoryLimit | default 3 }}
  startingDeadlineSeconds: {{ .startingDeadlineSeconds | default 180 }}
  jobTemplate:
    spec:
      backoffLimit: {{ .backoffLimit | default 2 }}
      completions: {{ .completions | default 1 }}
      parallelism: {{ .parallelism | default 1 }}
      template:
        metadata:
          labels: {{- toYaml $podLabels | nindent 12 }}
        spec:
          serviceAccountName: {{ .serviceAccount.name | default "default"}}
          {{- if .node_selector_labels }}
          nodeSelector: {{- toYaml .node_selector_labels | nindent 12 }}
          {{- end }}
          {{if .imagePullSecrets}}
          imagePullSecrets:
          - name: {{ .imagePullSecrets }}
          {{end}}
          restartPolicy: {{ .restartPolicy | default "OnFailure" }}
          containers:
            {{- range .containers }}
            - name: {{ .name }}
              image: {{ .image }}:{{ .tag }}
              imagePullPolicy: {{ .imagePullPolicy }}

              {{- if .command }}
              command: 
                {{- toYaml .command | nindent 16 }}
              {{- end }}

              {{- if .args }}
              args: 
                {{- toYaml .args | nindent 16 }}
              {{- end }}

              {{- if .env_from }}
              envFrom:
                {{- range .env_from }}
                {{- if eq .source "configMapRef" }}
                - configMapRef:
                    name: {{ .name }}
                {{- else if eq .source "secretRef" }}
                - secretRef:
                    name: {{ .name }}
                {{- end }}
                {{- end }}
              {{- end }}

              {{- if .env }}
              env:
                {{- range .env }}
                {{- if .value }}
                - name: {{ .name }}
                  value: {{ .value | quote }}
                {{- else if and .ref .ref.source }}
                  {{- if eq .ref.source "configMapRef" }}
                - name: {{ .name }}
                  valueFrom:
                    configMapKeyRef:
                      name: {{ .ref.name }}
                      key: {{ .ref.key }}
                  {{- else if eq .ref.source "secretKeyRef" }}
                - name: {{ .name }}
                  valueFrom:
                    secretKeyRef:
                      name: {{ .ref.name }}
                      key: {{ .ref.key }}
                  {{- end }}
                {{- end }}
                {{- end }}
              {{- end }}

              {{- if .resources }}
              resources:
                {{- with .resources.limits }}
                limits:
                  {{- toYaml . | nindent 18 }}
                {{- end }}
                {{- with .resources.requests }}
                requests:
                  {{- toYaml . | nindent 18 }}
                {{- end }}
              {{- end }}
            {{- end }}
        {{- end }}