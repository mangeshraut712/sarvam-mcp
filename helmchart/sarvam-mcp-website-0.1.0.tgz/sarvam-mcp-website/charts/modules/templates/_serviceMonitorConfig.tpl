{{- define "modules.service_monitor" -}}
{{- if and .service_monitor_config (eq .service_monitor_config.enabled true) }}
---
apiVersion: monitoring.coreos.com/v1
kind: ServiceMonitor
metadata:
  name: {{ .name }}-{{ .namespace }}-sm
  namespace: {{ .namespace | default "monitoring" }}
  labels:
    release: {{ .service_monitor_config.prometheus_release_name | default "prometheus" }}
    {{- with .service_monitor_config.additional_labels }}
    {{- toYaml . | nindent 4 }}
    {{- end }}
spec:
  selector:
    matchLabels:
      app.kubernetes.io/name: {{ .name }}
      {{- with .kube_service_config.labels }}
      {{- toYaml . | nindent 6 }}
      {{- end }}
  namespaceSelector:
    matchNames:
      - {{ coalesce .kube_service_config.namespace .namespace }}
  endpoints:
    - port: {{ .service_monitor_config.port_name | default "http" }}
      interval: {{ .service_monitor_config.interval | default "60s" }}
      path: {{ .service_monitor_config.path | default "/metrics" }}
{{- end }}
{{- end }}

