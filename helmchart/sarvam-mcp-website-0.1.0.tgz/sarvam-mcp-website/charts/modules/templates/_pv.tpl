{{- define "modules.pv" -}}
---
apiVersion: v1
kind: PersistentVolume
metadata:
  name: {{ .name | required "name is required for PV" }}
  labels:
    type: "local"
spec:
  capacity:
    storage: {{ .storage | default "20Gi" }}
  accessModes:
    - {{ .access_modes | default "ReadWriteMany" }}
  persistentVolumeReclaimPolicy: {{ .reclaim_policy | default "Retain" }}
  storageClassName: {{ .storage_class_name | default "manual" }}
  hostPath:
    path: {{ .host_path | required "host_path is required for PV" }}
{{- end }}