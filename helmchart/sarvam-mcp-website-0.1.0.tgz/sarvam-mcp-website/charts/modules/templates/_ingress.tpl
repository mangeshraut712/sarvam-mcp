{{- define "modules.ingress" }}
{{- if .ingress.enabled }}
apiVersion: networking.k8s.io/v1
kind: Ingress
metadata:
  name: {{ .ingress.name }}
  namespace: {{ .namespace }}
  annotations:
    {{- if eq .ingress.platform "sarvam-os"}}
    kubernetes.io/ingress.class: {{ .ingress.class }}
    cert-manager.io/cluster-issuer: {{ .ingress.clusterIssuer }}
      {{- if .ingress.rewrite }}
    konghq.com/strip-path: 'true'
      {{- end }}
    {{- end }}

    {{- if eq .ingress.platform "azure" }}
      {{- if .ingress.AFD }}
        {{- if .ingress.rewriteRuleSet }}
    appgw.ingress.kubernetes.io/rewrite-rule-set: {{ .ingress.rewriteRuleSet }}
        {{- end }}
    appgw.ingress.kubernetes.io/request-timeout: {{ .ingress.requestTimeout | quote }}
    appgw.ingress.kubernetes.io/connection-draining: "true"
    appgw.ingress.kubernetes.io/connection-draining-timeout: {{ .ingress.connectionDrainingTimeout | quote }}
      {{- else }}
    cert-manager.io/acme-challenge-type: http01
    cert-manager.io/cluster-issuer: {{ .ingress.clusterIssuer }}
        {{- if .ingress.rewriteRuleSet }}
    appgw.ingress.kubernetes.io/rewrite-rule-set: {{ .ingress.rewriteRuleSet }}
        {{- end }}
    appgw.ingress.kubernetes.io/request-timeout: {{ .ingress.requestTimeout | quote }}
    appgw.ingress.kubernetes.io/connection-draining: "true"
    appgw.ingress.kubernetes.io/connection-draining-timeout: {{ .ingress.connectionDrainingTimeout | quote }}
      {{- end }}
    {{- end }}
spec:
  ingressClassName: {{ .ingress.class }}
  {{- if .ingress.tlsSecret}}
  tls:
    - hosts:
        - {{ .ingress.host }}
      secretName: {{ .ingress.tlsSecret }}
  {{- end }}
  rules:
    - host: {{ .ingress.host }}
      http:
        paths:
          {{- range .ingress.routes }}
          - path: {{ .path }}
            pathType: {{ .pathType | default "Prefix" }}
            backend:
              service:
                name: {{ default $.name .serviceName }}
                port:
                  number: {{ .port }}
          {{- end }}
{{- end }}
{{- end }}
