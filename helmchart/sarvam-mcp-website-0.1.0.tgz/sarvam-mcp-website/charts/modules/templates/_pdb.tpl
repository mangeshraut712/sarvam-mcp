{{- define "modules.pdb" -}}
---
apiVersion: policy/v1
kind: PodDisruptionBudget
metadata:
  name: {{ .name | required "name is required for PDB" }}-pdb
  namespace: {{ .namespace | default "default" }}
  labels:
    app: {{ .deployment.labels.app | default .name }}
spec:
  minAvailable: {{ .minAvailable | default 1 }}
  selector:
    matchLabels:
      app: {{ .deployment.labels.app | default .name }}
{{- end }}