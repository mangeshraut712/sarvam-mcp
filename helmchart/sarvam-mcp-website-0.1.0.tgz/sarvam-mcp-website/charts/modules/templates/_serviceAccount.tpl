{{- define "modules.serviceAccount" -}}
{{- if .serviceAccount.enabled }}
apiVersion: v1
kind: ServiceAccount
metadata:
  name: {{ .serviceAccount.name }}
  namespace: {{ .namespace }}
  {{- if .serviceAccount.role }}
  annotations:
    eks.amazon.com/role-arn: {{ .serviceAccount.role | quote }}
  {{- end }}
{{- end }}
{{- end }}