{{- define "modules.hpa" -}}
{{- if .hpa}}
{{- $defaultScaleTargetRefKind := "Deployment" -}}
{{- if and .scale_target_ref .hpa.scale_target_ref.kind }}
  {{- $defaultScaleTargetRefKind = .hpa.scale_target_ref.kind -}}
{{- end }}

{{- $defaultScaleTargetRefName := .name -}}
{{- if .deployment_name }}
  {{- $defaultScaleTargetRefName = .deployment_name -}}
{{- end }}
{{- if and .scale_target_ref .hpa.scale_target_ref.name }}
  {{- $defaultScaleTargetRefName = .hpa.scale_target_ref.Name -}}
{{- end }}

apiVersion: autoscaling/v2
kind: HorizontalPodAutoscaler
metadata:
  name: {{ .name }}-hpa
  namespace: {{ .namespace }}
spec:
  scaleTargetRef:
    apiVersion: "apps/v1"
    kind: {{ $defaultScaleTargetRefKind }}
    name: {{ $defaultScaleTargetRefName }}
  minReplicas: {{ .hpa.min_replicas | default 1 }}
  maxReplicas: {{ .hpa.max_replicas | default 1 }}
  {{if or .hpa.pod_scale_down .hpa.pod_scale_up }}
  behavior:
    {{- if .hpa.pod_scale_down }}
    scaleDown:
      policy:
        type: Pods
        value: {{ .hpa.pod_scale_down.value }}
        periodSeconds: {{ .hpa.pod_scale_down.period_seconds }}
    {{- end }}
    {{- if .hpa.pod_scale_up }}
    scaleUp:
      policy:
        type: Pods
        value: {{ .hpa.pod_scale_up.value }}
        periodSeconds: {{ .hpa.pod_scale_up.period_seconds }}
    {{- end }}
  {{- end }}
  {{- if or .hpa.external_metrics .hpa.resource_metrics }}
  metrics:
    {{- if .hpa.external_metrics }}
    - type: External
      external:
        metric:
          name: {{ .hpa.external_metrics.name }}
          selector:
            matchLabels: 
              {{- range $key, $value := .hpa.external_metrics.match_labels }}
              {{ $key }}: {{ $value }}
              {{- end }}
        target:
          type: {{ .hpa.external_metrics.target_type }}
          value: {{ .hpa.external_metrics.target_value }}
    {{- end }}
    {{- if .hpa.resource_metrics }}
    {{- range .hpa.resource_metrics }}
    - type: Resource
      resource:
        name: {{ .name }}
        target:
          type: {{ .target_type }}
          {{- if eq .target_type "Utilization" }}
          averageUtilization: {{ .target_value }}
          {{- else if eq .target_type "AverageValue"}}
          averageValue: {{ .target_value }}
          {{- end }}
    {{- end }}
    {{- end }}
  {{- end }}
{{- end}}
{{- end -}}
