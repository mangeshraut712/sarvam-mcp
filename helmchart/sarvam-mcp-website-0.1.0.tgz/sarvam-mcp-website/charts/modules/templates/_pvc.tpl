{{- define "modules.pvc" -}}
apiVersion: v1
kind: PersistentVolumeClaim
metadata:
  name: {{ .name | required "name is required for PVC" }}
  namespace: {{ .namespace | default "default" }}
spec:
  storageClassName: {{ .storage_class_name | default "manual" }}
  accessModes:
    - {{ .access_modes | default "ReadWriteMany" }}
  resources:
    requests:
      storage: {{ .storage | default "20Gi" }}
  {{- if .volume_name }}
  volumeName: {{ .volume_name }}
  {{- end }}
{{- end }}