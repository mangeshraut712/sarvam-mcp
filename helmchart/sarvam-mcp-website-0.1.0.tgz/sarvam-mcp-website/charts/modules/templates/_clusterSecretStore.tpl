{{- define "modules.clusterSecretStore" -}}
apiVersion: external-secrets.io/v1
kind: ClusterSecretStore
metadata:
  name: {{ .secretStoreDefinition.name }}
spec:
  provider:
    azurekv:
      vaultUrl: {{ .secretStoreDefinition.provider.azurekv.vaultUrl | quote }}
      authType: {{ .secretStoreDefinition.provider.azurekv.authType | default "ManagedIdentity" }}
      {{- if .secretStoreDefinition.provider.azurekv.identityId }}
      identityId: {{ .secretStoreDefinition.provider.azurekv.identityId | quote }}
      {{- end }}
{{- end }}