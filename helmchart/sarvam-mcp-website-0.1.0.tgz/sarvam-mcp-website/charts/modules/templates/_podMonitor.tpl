{{- define "modules.podMonitor" }}

{{- $defaultLabel := dict "release" (default "prometheus" .podMonitor.prometheusReleaseName) -}}
{{- $labels := $defaultLabel -}}
{{- if .podMonitor.AdditionalLabels}}
  {{- $labels = merge $labels .podMonitor.AdditionalLabels -}}
{{- end -}}

{{- $defaultMatchLabel := dict "app.kubernetes.io/name" .name -}}
{{- $matchLabels := $defaultMatchLabel -}}
{{- if .podMonitor.kubeServiceConfigLabels}}
  {{- $matchLabels = merge $matchLabels .podMonitor.kubeServiceConfigLabels -}}
{{- end -}}

{{- if .podMonitor.enabled}}
apiVersion: monitoring.coreos.com/v1
kind: PodMonitor
metadata:
  name: {{ .name}}-{{ .namespace }}-sm
  namespace: {{ .podMonitor.podMonitorNamespace | default "monitoring" }}
  labels:
    {{- toYaml $labels | nindent 4 }}
spec:
  selector:
    matchLabels: {{- toYaml $matchLabels | nindent 6 }}
  namespaceSelector:
    matchNames: 
      - {{ default .podMonitor.namespace .kube_service_configs.namespace }}
  podMetricsEndpoints:
    - port: {{ .podMonitor.portName}}
      interval: {{ .podMonitor.interval }}
      path: {{ .podMonitor.path }}
{{- end }}
{{- end }}
