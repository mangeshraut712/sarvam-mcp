{{- define "modules.secrets" -}}
{{- range .secretsData }}
---
apiVersion: v1
kind: Secret
metadata:
  name: {{ .name }}
  namespace: {{ $.namespace }}
type: Opaque
data:
  {{- range $key, $value := .data }}
  {{ $key }}: {{ $value | b64enc }}
  {{- end }}
  {{- if .generated_data }}
  {{- range .generated_data }}
  {{ .name }}: {{ randAlphaNum 8 | b64enc }}
  {{- end }}
  {{- end }}
{{- end }}
{{- end -}}