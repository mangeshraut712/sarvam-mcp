{{- define "modules.configmaps" -}}
{{- range .configs }}
  {{- $cfg := . }}
  {{- range $ns := .namespaces }}
---
apiVersion: v1
kind: ConfigMap
metadata:
  name: {{ $cfg.name }}
  namespace: {{ $ns }}
data:
  {{- toYaml $cfg.data | nindent 2 }}
  {{- end }}
{{- end }}
{{- end }}