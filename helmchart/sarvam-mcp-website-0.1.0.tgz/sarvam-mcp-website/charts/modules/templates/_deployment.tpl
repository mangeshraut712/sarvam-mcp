{{- define "modules.deployment" -}}

{{- $deploymentName := .name -}}
{{- if .deployment_name }}
  {{- $deploymentName = .deployment_name -}}
{{- end }}

{{- $namespace := .namespace -}}

{{- $defaultLabels := dict "app.kubernetes.io/name" .name -}}
{{- $labels := $defaultLabels -}}
{{- if .labels }}
  {{- $labels := merge $defaultLabels .labels -}}
{{- end }}

{{- $defaultMatchLabels := dict "app.kubernetes.io/name" .name -}}
{{- $matchLabels := $defaultMatchLabels -}}
{{- if .match_labels }}
  {{- $matchLabels := merge $defaultMatchLabels .match_labels -}}
{{- end }}

{{- $defaultPodLabels := dict 
    "app.kubernetes.io/name" .name
    "azure.workload.identity/use" "true" 
-}}
{{- $podLabels := $defaultPodLabels -}}
{{- if .pod_labels }}
  {{- $podLabels := merge $defaultPodLabels .pod_labels -}}
{{- end }}


{{- $defaultLivenessProbe := dict -}}
{{- if .apply_default_liveness_probe }}
{{- $defaultLivenessProbe = dict
    "protocol" "http_get"
    "port" (default 80 .liveliness_probe_port)
    "http_get_path" "/health"
    "initial_delay_seconds" 30
    "period_seconds" 10
    "timeout_seconds" 5
-}}
{{- end -}}

apiVersion: apps/v1
kind: Deployment
metadata:
  name: {{ $deploymentName }}
  namespace: {{ $namespace }}
  labels: 
    {{- toYaml $labels | nindent 4 }}
spec:
  {{- if not .hpa }}
  replicas: {{ .replicas | default 1 }}
  {{- end }}
  selector:
    matchLabels: {{- toYaml $matchLabels | nindent 6 }}
  template:
    metadata:
      labels: {{- toYaml $podLabels | nindent 8 }}
      {{if .prometheus_annotations}}
      annotations: {{- toYaml .prometheus_annotations | nindent 8 }}
      {{end}}
    spec:
      serviceAccountName: {{ .serviceAccount.name | default "default"}}
      {{if .node_selector_labels}}
      nodeSelector: 
      {{- toYaml .node_selector_labels | nindent 8 }}
      {{end}}
      {{if .imagePullSecrets}}
      imagePullSecrets:
      - name: {{ .imagePullSecrets }}
      {{end}}
      terminationGracePeriodSeconds: {{ .pod_termination_grace_period_seconds | default 90}}

      {{- if or .memory_volume_def .pvc_volume_def }}
      volumes:
        {{- if .memory_volume_def }}
        {{- range .memory_volume_def }}
        - name: {{ .name }}
          emptyDir:
            medium: {{ .medium }}
            {{- if .size_limit }}
            sizeLimit: {{ .size_limit }}
            {{- end }}
        {{- end }}
        {{- end }}

        {{- if .pvc_volume_def }}
        {{- range .pvc_volume_def }}
        - name: {{ .name }}
          persistentVolumeClaim:
            claimName: {{ .claim_name }}
            readOnly: {{ .read_only | default false }}
        {{- end }}
        {{- end }}
      {{- end }}

      {{- if .gpu_toleration }}
      tolerations:
        - key: "sku"
          operator: "Equal"
          value: "gpu"
          effect: "NoSchedule"
      {{- end }}

      containers:
        {{- range .containers }}
        - name: {{ .name }}
          image: {{ .image }}:{{ .tag }}
          imagePullPolicy: {{ .imagePullPolicy }}

          lifecycle:
            preStop:
              exec:
                command: ["sleep", "{{ $.pod_termination_grace_period_seconds | default 90 }}"]
          
          {{- if .env_from }}
          envFrom:
            {{- range .env_from }}
            {{- if eq .source "configMapRef" }}
            - configMapRef:
                name: {{ .name }}
            {{- else if eq .source "secretRef" }}
            - secretRef:
                name: {{ .name }}
            {{- end }}
            {{- end }}
          {{- end }}

          {{- if .env }}
          env:
            {{- range .env }}
            {{- if .value }}
              {{- $tp := typeOf .value }}
              {{- if or (eq $tp "bool") (eq $tp "float64") (eq $tp "string")}}
            - name: {{ .name }}
              value: {{ .value | quote }}
              {{- else }}
            - name: {{ .name }}
              value: {{ .value }}
              {{- end}}
            {{- else if and .ref .ref.source }}
              {{- if eq .ref.source "configMapKeyRef" }}
            - name: {{ .name }}
              valueFrom:
                configMapKeyRef:
                  name: {{ .ref.name }}
                  key: {{ .ref.key }}
              {{- else if eq .ref.source "secretKeyRef" }}
            - name: {{ .name }}
              valueFrom:
                secretKeyRef:
                  name: {{ .ref.name }}
                  key: {{ .ref.key }}
              {{- end}}
            {{- end}}
            {{- end }}
          {{- end }}

          ports:
            {{- range .ports }}
            - name: {{ .name }}
              containerPort: {{ .container_port }}
              protocol: {{ .protocol }}
            {{- end }}

          volumeMounts:
            {{- range .volume_mounts }}
            - mountPath: {{ .mount_path }}
              name: {{ .name }}
              readOnly: {{ .read_only | default false}}
            {{- end }}

          {{- if or (and .probes .probes.liveness) $.apply_default_liveness_probe }}
          livenessProbe:
            {{- $livenessProbe := $defaultLivenessProbe -}}
            {{- if and .probes .probes.liveness }}
              {{- $livenessProbe = .probes.liveness -}}
            {{- end }}
            {{- if eq $livenessProbe.protocol "http_get" }}
            httpGet:
              path: {{ $livenessProbe.http_get_path }}
              port: {{ $livenessProbe.port }}
            {{- else if eq $livenessProbe.protocol "grpc" }}
            grpc:
              port: {{ $livenessProbe.port }}
            {{- end }}
            initialDelaySeconds: {{ $livenessProbe.initial_delay_seconds }}
            periodSeconds: {{ $livenessProbe.period_seconds }}
            timeoutSeconds: {{ $livenessProbe.timeout_seconds }}
          {{- end }}

          {{- if and .probes .probes.readiness }}
          readinessProbe:
            {{- if eq .probes.readiness.protocol "http_get" }}
            httpGet:
              path: {{ .probes.readiness.http_get_path }}
              port: {{ .probes.readiness.port }}
            {{- else if eq .probes.readiness.protocol "grpc" }}
            grpc:
              port: {{ .probes.readiness.port }}
            {{- end }}
            initialDelaySeconds: {{ .probes.readiness.initial_delay_seconds }}
            periodSeconds: {{ .probes.readiness.period_seconds }}
            timeoutSeconds: {{ .probes.readiness.timeout_seconds }}
          {{- end }}

          {{- if and .probes .probes.startup }}
          startupProbe:
            {{- if eq .probes.startup.protocol "http_get" }}
            httpGet:
              path: {{ .probes.startup.http_get_path }}
              port: {{ .probes.startup.port }}
            {{- else if eq .probes.startup.protocol "grpc" }}
            grpc:
              port: {{ .probes.startup.port }}
            {{- end }}
            initialDelaySeconds: {{ .probes.startup.initial_delay_seconds }}
            periodSeconds: {{ .probes.startup.period_seconds }}
            timeoutSeconds: {{ .probes.startup.timeout_seconds }}
          {{- end }}

          {{- if .resources }}
          resources:
            {{- if .resources.limits }}
            limits: {{- toYaml .resources.limits | nindent 14 }}
            {{- end }}
            {{- if .resources.requests }}
            requests: {{- toYaml .resources.requests | nindent 14 }}
          {{- end }}
        {{- end }}
      {{- end }}
    {{- end }}