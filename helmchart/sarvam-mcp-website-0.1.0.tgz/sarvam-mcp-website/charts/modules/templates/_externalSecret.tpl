{{- define "modules.externalSecret" -}}
{{- if .secrets.enabled }}
apiVersion: external-secrets.io/v1 
kind: ExternalSecret
metadata:
  name: {{ .secrets.kubernetesSecretName }}
  namespace: {{ .namespace }}
  labels:
    {{- range $key, $value := .commonLabels }}
    {{ $key }}: {{ tpl $value $ | quote }}
    {{- end }}
spec:
  refreshInterval: 1m
  secretStoreRef:
    name: {{ .secrets.secretStoreRef.name }}
    kind: {{ .secrets.secretStoreRef.kind }}
  target:
    name: {{ .secrets.kubernetesSecretName }}
    creationPolicy: Owner
  data:
    {{- if eq .secrets.keyVault "openbao"}}
    {{- range $key, $value := .secrets.vaultSecrets }}
    - secretKey: {{ $key }} # key name in k8s secret
      remoteRef:
        key: {{ $.secrets.remoteRefKey }} # secret name in vault
        property: {{ $value }} # secret key in vault
    {{- end }}
    {{- end}}
    {{- if eq .secrets.keyVault "azurekv"}}
    {{- range $key, $value := .secrets.vaultSecrets }}
    - secretKey: {{ $key }}
      remoteRef:
        key: {{ $value }}
    {{- end }}
    {{- end }}
{{- end }}
{{- end }}