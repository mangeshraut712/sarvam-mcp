{{- define "modules.nginxIngress" }}
{{- if .ingress.enabled }}
apiVersion: networking.k8s.io/v1
kind: Ingress
metadata:
  name: {{ .name }}-nginx-ingress
  namespace: {{ .namespace }}
  annotations:
    nginx.ingress.kubernetes.io/rewrite-target: {{ .ingress.rewriteTarget | default "/" | quote }}
    nginx.ingress.kubernetes.io/ssl-redirect: "{{ .ingress.sslRedirect | default "true" }}"
    nginx.ingress.kubernetes.io/proxy-body-size: "50m"
    nginx.ingress.kubernetes.io/proxy-read-timeout: "600"
    nginx.ingress.kubernetes.io/proxy-send-timeout: "600"
    nginx.ingress.kubernetes.io/connection-proxy-header: "keep-alive"
    nginx.ingress.kubernetes.io/use-regex: "true"
    {{- if .ingress.successCodes }}
    nginx.ingress.kubernetes.io/success-codes: "{{ .ingress.successCodes }}"
    {{- end }}
    # {{- if .ingress.healthCheck.path }}
    # alb.ingress.kubernetes.io/healthcheck-path: "{{ .ingress.healthCheck.path }}"
    # {{- end }}
    # {{- if .ingress.healthCheck.port }}
    # alb.ingress.kubernetes.io/healthcheck-port: "{{ .ingress.healthCheck.port }}"
    # {{- end }}
    {{- if .ingress.rewritePathSnippet }}
    nginx.ingress.kubernetes.io/configuration-snippet: |
      {{- .ingress.rewritePathSnippet | nindent 6 }}
    {{- end }}
    {{- if .ingress.additionalAnnotations }}
{{ toYaml .ingress.additionalAnnotations | indent 4 }}
    {{- end }}
spec:
  ingressClassName: {{ .ingress.classNamenginx | default "nginx" }}
  rules:
    - host: {{ .ingress.host }}
      http:
        paths:
          {{- range .ingress.routes }}
          - path: {{ .path }}
            pathType: {{ .pathType | default "Prefix" }}
            backend:
              service:
                name: {{ $.name }}
                port:
                  number: {{ .port }}
          {{- end }}
{{- end }}
{{- end }}
